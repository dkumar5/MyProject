My Project
----------

This is the description of *My Project*.
It is a project which is mine.

So far I have:

* made a README.md file
* initialized git in this directory
* added the README.md file to those being tracked

